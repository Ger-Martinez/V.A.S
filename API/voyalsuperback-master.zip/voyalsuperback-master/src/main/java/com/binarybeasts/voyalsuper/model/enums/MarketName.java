package com.binarybeasts.voyalsuper.model.enums;

public enum MarketName {
    JUMBO,DIA,CARREFOUR
}
