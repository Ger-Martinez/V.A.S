package com.binarybeasts.voyalsuper.model.enums;

public enum ProductCategory {
    ALIMENTOS_CONGELADOS, ALMACEN, BEBIDAS_CON_ALCOHOL, BEBIDAS_SIN_ALCOHOL,
        BEBES, FRESCOS, LIMPIEZA, MASCOTAS, PERFUMERIA_CUIDADO_PERSONAL
}
