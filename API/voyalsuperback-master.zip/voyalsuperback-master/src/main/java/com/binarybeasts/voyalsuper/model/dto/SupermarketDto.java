package com.binarybeasts.voyalsuper.model.dto;

import com.binarybeasts.voyalsuper.model.enums.MarketName;

public class SupermarketDto {

    MarketName name;

    public SupermarketDto() {
    }

    public MarketName getName() {
        return name;
    }
}
