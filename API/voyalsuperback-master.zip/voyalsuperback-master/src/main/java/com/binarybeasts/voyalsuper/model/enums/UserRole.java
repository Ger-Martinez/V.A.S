package com.binarybeasts.voyalsuper.model.enums;

public enum UserRole {
    ROLE_USER, ROLE_ADMIN
}
