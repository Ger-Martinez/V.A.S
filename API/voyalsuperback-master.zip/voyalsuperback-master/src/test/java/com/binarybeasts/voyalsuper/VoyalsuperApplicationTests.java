package com.binarybeasts.voyalsuper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoyalsuperApplicationTests {

    @Test
    void contextLoads() {
    }

}
